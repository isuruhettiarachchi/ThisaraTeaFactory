/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thisarateafactory.ui.Supplier.Payment;

/**
 *
 * @author user pc
 */
public class paylist {
    
    private String Bill;
    private String paydate;
    private String SupplierID;
    private String supleave; 
    private String rate;    
    private String payamount;
    private String trans;
    private String grosspay;
    private String tead;
    private String cash;    
    private String ferty;
    private String balpay;

    public paylist(String Bill, String paydate, String SupplierID, String supleave, String rate, String payamount, String trans, String grosspay, String tead, String cash, String ferty, String balpay) {
        this.Bill = Bill;
        this.paydate = paydate;
        this.SupplierID = SupplierID;
        this.supleave = supleave;
        this.rate = rate;
        this.payamount = payamount;
        this.trans = trans;
        this.grosspay = grosspay;
        this.tead = tead;
        this.cash = cash;
        this.ferty = ferty;
        this.balpay = balpay;
    }

    /**
     * @return the Bill
     */
    public String getBill() {
        return Bill;
    }

    /**
     * @param Bill the Bill to set
     */
    public void setBill(String Bill) {
        this.Bill = Bill;
    }

    /**
     * @return the paydate
     */
    public String getPaydate() {
        return paydate;
    }

    /**
     * @param paydate the paydate to set
     */
    public void setPaydate(String paydate) {
        this.paydate = paydate;
    }

    /**
     * @return the SupplierID
     */
    public String getSupplierID() {
        return SupplierID;
    }

    /**
     * @param SupplierID the SupplierID to set
     */
    public void setSupplierID(String SupplierID) {
        this.SupplierID = SupplierID;
    }

    /**
     * @return the supleave
     */
    public String getSupleave() {
        return supleave;
    }

    /**
     * @param supleave the supleave to set
     */
    public void setSupleave(String supleave) {
        this.supleave = supleave;
    }

    /**
     * @return the rate
     */
    public String getRate() {
        return rate;
    }

    /**
     * @param rate the rate to set
     */
    public void setRate(String rate) {
        this.rate = rate;
    }

    /**
     * @return the payamount
     */
    public String getPayamount() {
        return payamount;
    }

    /**
     * @param payamount the payamount to set
     */
    public void setPayamount(String payamount) {
        this.payamount = payamount;
    }

    /**
     * @return the trans
     */
    public String getTrans() {
        return trans;
    }

    /**
     * @param trans the trans to set
     */
    public void setTrans(String trans) {
        this.trans = trans;
    }

    /**
     * @return the grosspay
     */
    public String getGrosspay() {
        return grosspay;
    }

    /**
     * @param grosspay the grosspay to set
     */
    public void setGrosspay(String grosspay) {
        this.grosspay = grosspay;
    }

    /**
     * @return the tead
     */
    public String getTead() {
        return tead;
    }

    /**
     * @param tead the tead to set
     */
    public void setTead(String tead) {
        this.tead = tead;
    }

    /**
     * @return the cash
     */
    public String getCash() {
        return cash;
    }

    /**
     * @param cash the cash to set
     */
    public void setCash(String cash) {
        this.cash = cash;
    }

    /**
     * @return the ferty
     */
    public String getFerty() {
        return ferty;
    }

    /**
     * @param ferty the ferty to set
     */
    public void setFerty(String ferty) {
        this.ferty = ferty;
    }

    /**
     * @return the balpay
     */
    public String getBalpay() {
        return balpay;
    }

    /**
     * @param balpay the balpay to set
     */
    public void setBalpay(String balpay) {
        this.balpay = balpay;
    }
    
    
    
   
}
