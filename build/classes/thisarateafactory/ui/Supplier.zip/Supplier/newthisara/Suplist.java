/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thisarateafactory.ui.Supplier.newthisara;

/**
 *
 * @author user pc
 */
public class Suplist {
    
    
        private String supid ;
        private String name ;
        private String add ;
        private String lname ;
        private String gnd ;
        private String larea ;
        private String nic ;        
        private String conno ;

    public Suplist(String supid, String name, String add, String lname, String gnd, String larea, String nic, String conno) {
        this.supid = supid;
        this.name = name;
        this.add = add;
        this.lname = lname;
        this.gnd = gnd;
        this.larea = larea;
        this.nic = nic;
        this.conno = conno;
    }

    /**
     * @return the supid
     */
    public String getSupid() {
        return supid;
    }

    /**
     * @param supid the supid to set
     */
    public void setSupid(String supid) {
        this.supid = supid;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the add
     */
    public String getAdd() {
        return add;
    }

    /**
     * @param add the add to set
     */
    public void setAdd(String add) {
        this.add = add;
    }

    /**
     * @return the lname
     */
    public String getLname() {
        return lname;
    }

    /**
     * @param lname the lname to set
     */
    public void setLname(String lname) {
        this.lname = lname;
    }

    /**
     * @return the gnd
     */
    public String getGnd() {
        return gnd;
    }

    /**
     * @param gnd the gnd to set
     */
    public void setGnd(String gnd) {
        this.gnd = gnd;
    }

    /**
     * @return the larea
     */
    public String getLarea() {
        return larea;
    }

    /**
     * @param larea the larea to set
     */
    public void setLarea(String larea) {
        this.larea = larea;
    }

    /**
     * @return the nic
     */
    public String getNic() {
        return nic;
    }

    /**
     * @param nic the nic to set
     */
    public void setNic(String nic) {
        this.nic = nic;
    }

    /**
     * @return the conno
     */
    public String getConno() {
        return conno;
    }

    /**
     * @param conno the conno to set
     */
    public void setConno(String conno) {
        this.conno = conno;
    }
        
        
       

    
}
