package thisarateafactory.ui.Finance.Summary;

/**
 *
 * @author Chinthaka
 */
public class SummaryList {
    
    private String mnt;
    private String yr;
    private String income;
    private String cost;
    private String net;

    public SummaryList(String mnt, String yr, String income, String cost, String net) {
        this.mnt = mnt;
        this.yr = yr;
        this.income = income;
        this.cost = cost;
        this.net = net;
    }
    
    
}
