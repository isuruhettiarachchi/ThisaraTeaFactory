/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thisarateafactory.ui.Production.thisara;

/**
 *
 * @author Nipuni
 */
public class DailyProductList {
    
    private String proID ;
    private String date ;
    private String GreenLeavesWeightToday;
    private String MadeTeaToday;
    private String OutTurnToday;
    private String FiredTeaWeightToday;
    private String RefTeaToday;
    private String dhool1;
    private String dhool2 ;
    private String dhool3 ;
    private String dhool4 ;

    public DailyProductList(String proID, String date, String GreenLeavesWeightToday, String MadeTeaToday, String OutTurnToday, String FiredTeaWeightToday, String RefTeaToday, String dhool1, String dhool2, String dhool3, String dhool4) {
        this.proID = proID;
        this.date = date;
        this.GreenLeavesWeightToday = GreenLeavesWeightToday;
        this.MadeTeaToday = MadeTeaToday;
        this.OutTurnToday = OutTurnToday;
        this.FiredTeaWeightToday = FiredTeaWeightToday;
        this.RefTeaToday = RefTeaToday;
        this.dhool1 = dhool1;
        this.dhool2 = dhool2;
        this.dhool3 = dhool3;
        this.dhool4 = dhool4;
    }

    /**
     * @return the proID
     */
    public String getProID() {
        return proID;
    }

    /**
     * @param proID the proID to set
     */
    public void setProID(String proID) {
        this.proID = proID;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return this.date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return the GreenLeavesWeightToday
     */
    public String getGreenLeavesWeightToday() {
        return GreenLeavesWeightToday;
    }

    /**
     * @param GreenLeavesWeightToday the GreenLeavesWeightToday to set
     */
    public void setGreenLeavesWeightToday(String GreenLeavesWeightToday) {
        this.GreenLeavesWeightToday = GreenLeavesWeightToday;
    }

    /**
     * @return the MadeTeaToday
     */
    public String getMadeTeaToday() {
        return MadeTeaToday;
    }

    /**
     * @param MadeTeaToday the MadeTeaToday to set
     */
    public void setMadeTeaToday(String MadeTeaToday) {
        this.MadeTeaToday = MadeTeaToday;
    }

    /**
     * @return the OutTurnToday
     */
    public String getOutTurnToday() {
        return OutTurnToday;
    }

    /**
     * @param OutTurnToday the OutTurnToday to set
     */
    public void setOutTurnToday(String OutTurnToday) {
        this.OutTurnToday = OutTurnToday;
    }

    /**
     * @return the FiredTeaWeightToday
     */
    public String getFiredTeaWeightToday() {
        return FiredTeaWeightToday;
    }

    /**
     * @param FiredTeaWeightToday the FiredTeaWeightToday to set
     */
    public void setFiredTeaWeightToday(String FiredTeaWeightToday) {
        this.FiredTeaWeightToday = FiredTeaWeightToday;
    }

    /**
     * @return the RefTeaToday
     */
    public String getRefTeaToday() {
        return RefTeaToday;
    }

    /**
     * @param RefTeaToday the RefTeaToday to set
     */
    public void setRefTeaToday(String RefTeaToday) {
        this.RefTeaToday = RefTeaToday;
    }

    /**
     * @return the dhool1
     */
    public String getDhool1() {
        return dhool1;
    }

    /**
     * @param dhool1 the dhool1 to set
     */
    public void setDhool1(String dhool1) {
        this.dhool1 = dhool1;
    }

    /**
     * @return the dhool2
     */
    public String getDhool2() {
        return dhool2;
    }

    /**
     * @param dhool2 the dhool2 to set
     */
    public void setDhool2(String dhool2) {
        this.dhool2 = dhool2;
    }

    /**
     * @return the dhool3
     */
    public String getDhool3() {
        return dhool3;
    }

    /**
     * @param dhool3 the dhool3 to set
     */
    public void setDhool3(String dhool3) {
        this.dhool3 = dhool3;
    }

    /**
     * @return the dhool4
     */
    public String getDhool4() {
        return dhool4;
    }

    /**
     * @param dhool4 the dhool4 to set
     */
    public void setDhool4(String dhool4) {
        this.dhool4 = dhool4;
    }
    
    

    
    
    
    
    
    
    
}
